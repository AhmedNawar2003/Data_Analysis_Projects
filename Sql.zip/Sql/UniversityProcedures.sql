
-- CREATING PROCEDURES

-- 1. Number of instructors in each department
CREATE PROCEDURE GetNumInstructorsPerDept
AS
BEGIN
   SELECT D.Dep_Name , COUNT(I.Instructor_ID) AS Num_Instructors
   FROM Department D
   LEFT JOIN Instructor I ON D.Dep_ID = I.Dep_ID
   GROUP BY Dep_Name;
END;
GO

-- 2. Department that offers maximum number of courses
CREATE PROCEDURE GetDeptWithMaxCourses
AS
BEGIN
    SELECT TOP 1 D.Dep_Name, COUNT(C.Course_ID) AS Num_Courses
    FROM Department D
    JOIN Course C ON D.Dep_ID = C.Dep_ID
    GROUP BY D.Dep_Name
    ORDER BY Num_Courses DESC;
END;
GO

-- 3. Name of each instructor with courses he teaches
CREATE PROCEDURE GetInstructorCourses
AS
BEGIN
    SELECT I.Instructor_Name, C.Course_Name
    FROM Instructor I
    JOIN Section S ON I.Instructor_ID = S.Instructor_ID
    JOIN Course C ON S.Course_ID = C.Course_ID;
END;
GO

-- 4. Number of students in each department
CREATE PROCEDURE GetNumStudentsPerDept
AS
BEGIN
    SELECT D.Dep_Name , COUNT(S.Student_ID) AS Num_Students
    FROM Department D 
    JOIN Student S ON D.Dep_ID = S.Major_Department
    GROUP BY Dep_Name;
END;
GO

-- 5. Department that pays maximum total salary
CREATE PROCEDURE GetDeptWithMaxSalary
AS
BEGIN
    SELECT TOP 1 D.Dep_Name, SUM(I.Salary) AS Total_Salary
    FROM Department D
    JOIN Instructor I ON D.Dep_ID = I.Dep_ID
    GROUP BY D.Dep_Name
    ORDER BY Total_Salary DESC;
END;
GO

-- 6. Student with maximum number of courses
CREATE PROCEDURE GetStudentWithMaxCourses
AS
BEGIN
    SELECT TOP 1 D.Dep_Name, COUNT(S.Student_ID) AS Num_Students
    FROM Department D
    JOIN Student S ON D.Dep_ID = S.Major_Department
    GROUP BY D.Dep_Name
    ORDER BY Num_Students DESC;
END;
GO

-- 7. Instructors with salary > avg salary of their department
CREATE PROCEDURE GetAboveAvgSalaryInstructors
AS
BEGIN
    SELECT I.Instructor_Name, I.Salary, D.Dep_Name
    FROM Instructor I
    JOIN Department D ON I.Dep_ID = D.Dep_ID
    WHERE I.Salary > (
        SELECT AVG(I2.Salary) 
        FROM Instructor I2 
        WHERE I2.Dep_ID = I.Dep_ID
    )
    ORDER BY Salary DESC;

END;
GO

-- 8. Department office phone of dept with highest-paid instructor
CREATE PROCEDURE GetDeptPhoneOfHighestPaidInstructor
AS
BEGIN
    SELECT TOP 1 D.Dep_Name, D.Office_Phone, I.Instructor_Name, I.Salary
    FROM Department D
    JOIN Instructor I ON D.Dep_ID = I.Dep_ID
    ORDER BY I.Salary DESC;
END;
GO

-- 9. Students enrolled in > 3 courses
CREATE PROCEDURE GetStudentsWithMoreThan3Courses
AS
BEGIN
    SELECT S.Student_Name, COUNT(E.Section_ID) AS Num_Courses
    FROM Student S
    JOIN Enrollment E ON S.Student_ID = E.Student_ID
    GROUP BY S.Student_Name
    HAVING COUNT(E.Section_ID) > 3;

END;
GO

-- 10. Number of instructors in each course
CREATE PROCEDURE GetNumInstructorsPerCourse
AS
BEGIN
    SELECT C.Course_Name, COUNT(DISTINCT S.Instructor_ID) AS Num_Instructors
    FROM Course C
    JOIN Section S ON C.Course_ID = S.Course_ID
    GROUP BY C.Course_Name;
END;
GO


EXEC GetNumInstructorsPerDept;
EXEC GetDeptWithMaxCourses;
EXEC GetInstructorCourses;
EXEC GetNumStudentsPerDept;
EXEC GetDeptWithMaxSalary;
EXEC GetStudentWithMaxCourses;
EXEC GetAboveAvgSalaryInstructors;
EXEC GetDeptPhoneOfHighestPaidInstructor;
EXEC GetStudentsWithMoreThan3Courses;
EXEC GetNumInstructorsPerCourse;

