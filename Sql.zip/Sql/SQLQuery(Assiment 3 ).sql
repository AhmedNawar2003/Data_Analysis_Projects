
SELECT * 
FROM Base;

SELECT * 
FROM sec;

-- Q: 1. Use a subquery to find employees who earn more than the average salary. 

--Average of Salary = 9582,966

SELECT Name, Department, Salary
FROM Base
WHERE Salary > (SELECT AVG(Salary) FROM Base);


-- Q: 2. Create a CTE to list employees hired in the last 5 years and show their names and hire dates. 

--Hightest date that exist 2025-07-11
WITH RecentHires AS (
    SELECT Name, HireDate
    FROM Base
    WHERE HireDate >= '2019-07-12'
)
SELECT * 
FROM RecentHires;

--Q: 3. Use a window function to rank employees by salary within each department. 

-- 1 - USE RANK()
SELECT Name, Department , Salary,
RANK() OVER(PARTITION BY Department ORDER BY Salary DESC) AS SalaryRank
FROM Base;

-- 2 - USE DENSE_RANK
SELECT Name, Department , Salary,
DENSE_RANK() OVER(PARTITION BY Department ORDER BY Salary DESC) AS Salary_Dense_Rank
FROM Base;

-- 3 - USE ROW_NUMBER
SELECT Name, Department , Salary,
ROW_NUMBER() OVER(PARTITION BY Department ORDER BY Salary DESC) AS Salary_Row_Number
FROM Base;

-- 4 - USE SUM
SELECT Name, Department , Salary,
SUM(Salary) OVER(PARTITION BY Department ORDER BY Salary DESC) AS TotalSalary
FROM Base;
/*******************************************************************************/

-- Q: 4. Review: Get the total number of employees per department. 

SELECT Department, COUNT(*) AS TotalEmployeesByDep
FROM Base
GROUP BY Department;

--USING ORDER BY COUNT(*)
SELECT Department, COUNT(*) AS TotalEmployeesByDep
FROM Base
GROUP BY Department
ORDER BY COUNT(*) DESC;

-- Q: 5. Review: List employees with a salary greater than 10,000. 

SELECT Name , Department , JobTitle , Salary
FROM Base
WHERE Salary > 10000;