CREATE TABLE Department(
    Dep_ID INT PRIMARY KEY IDENTITY(1,1),
    Dep_Name VARCHAR(100) UNIQUE NOT NULL,
    Dep_Code VARCHAR(10) UNIQUE NOT NULL,
    Office_Number VARCHAR(20),
    Office_Phone VARCHAR(20),
    College VARCHAR(100)
);

CREATE TABLE Instructor (
    Instructor_ID INT PRIMARY KEY IDENTITY(1,1),
    Instructor_Name VARCHAR(100) NOT NULL,
    Dep_ID INT NOT NULL,
    FOREIGN KEY (Dep_ID) REFERENCES Department(Dep_ID)
);

CREATE TABLE Course (
    Course_ID INT PRIMARY KEY IDENTITY(1,1),
    Course_Name VARCHAR(100) NOT NULL,
    Course_Description VARCHAR(500),
    Course_Number VARCHAR(20) UNIQUE NOT NULL,
    Semester VARCHAR(20),
    Dep_ID INT NOT NULL,
    FOREIGN KEY (Dep_ID) REFERENCES Department(Dep_ID)
);

CREATE TABLE Semester(
    Semester_ID INT PRIMARY KEY IDENTITY(1,1),
    Semester_Name VARCHAR(50) NOT NULL,
    Year INT NOT NULL
);

CREATE TABLE Section(
    Section_ID INT PRIMARY KEY IDENTITY(1,1),
    Course_ID INT NOT NULL,
    Section_Number INT NOT NULL,
    Semester_ID INT NOT NULL,
    Instructor_ID INT NOT NULL,
    FOREIGN KEY (Course_ID) REFERENCES Course(Course_ID),
    FOREIGN KEY (Semester_ID) REFERENCES Semester(Semester_ID),
    FOREIGN KEY (Instructor_ID) REFERENCES Instructor(Instructor_ID)
);

CREATE TABLE Student(
    Student_ID INT PRIMARY KEY IDENTITY(1,1),
    Student_Name VARCHAR(100) NOT NULL,
    SSN INT UNIQUE NOT NULL,
    Current_Address VARCHAR(200),
    Current_Phone VARCHAR(20),
    Permanent_Address VARCHAR(200),
    Permanent_Phone VARCHAR(20),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(10),
    BirthDate DATE,
    Sex VARCHAR(10), 
    Study_Year INT,
    Major_Department INT,
    FOREIGN KEY (Major_Department) REFERENCES Department(Dep_ID)
);

CREATE TABLE Enrollment (
    Enrollment_ID INT PRIMARY KEY IDENTITY(1,1),
    Student_ID INT NOT NULL,
    Section_ID INT NOT NULL,
    Grade VARCHAR(5),
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    FOREIGN KEY (Section_ID) REFERENCES Section(Section_ID)
);

-- Department
INSERT INTO Department (Dep_Name, Dep_Code, Office_Number, Office_Phone, College) VALUES
('Computer Science', 'CS', 'B101', '123-1111', 'Engineering'),
('Information Systems', 'IS', 'B102', '123-2222', 'Engineering'),
('Mathematics', 'MATH', 'C201', '123-3333', 'Science'),
('Physics', 'PHYS', 'C202', '123-4444', 'Science'),
('Business Admin', 'BUS', 'D301', '123-5555', 'Business'),
('Accounting', 'ACC', 'D302', '123-6666', 'Business'),
('English', 'ENG', 'E101', '123-7777', 'Arts'),
('History', 'HIST', 'E102', '123-8888', 'Arts'),
('Mechanical Eng', 'MECH', 'F101', '123-9999', 'Engineering'),
('Electrical Eng', 'ELEC', 'F102', '123-0000', 'Engineering');

-- Instructor
INSERT INTO Instructor (Instructor_Name, Dep_ID) VALUES
('Dr. Ali Hassan', 1),
('Dr. Mona Said', 1),
('Dr. Ahmed Youssef', 2),
('Dr. Salma Fathy', 3),
('Dr. Hany Nabil', 4),
('Dr. Nourhan Adel', 5),
('Dr. Karim Samir', 6),
('Dr. Sara Magdy', 7),
('Dr. Tamer Khaled', 8),
('Dr. Wael Mohamed', 9);

ALTER TABLE Instructor ADD Salary DECIMAL(10,2);
UPDATE Instructor SET Salary = 15000 WHERE Instructor_ID = 1;
UPDATE Instructor SET Salary = 12000 WHERE Instructor_ID = 2;
UPDATE Instructor SET Salary = 18000 WHERE Instructor_ID = 3;
UPDATE Instructor SET Salary = 14000 WHERE Instructor_ID = 4;
UPDATE Instructor SET Salary = 17000 WHERE Instructor_ID = 5;
UPDATE Instructor SET Salary = 16000 WHERE Instructor_ID = 6;
UPDATE Instructor SET Salary = 13000 WHERE Instructor_ID = 7;
UPDATE Instructor SET Salary = 15500 WHERE Instructor_ID = 8;
UPDATE Instructor SET Salary = 14500 WHERE Instructor_ID = 9;
UPDATE Instructor SET Salary = 20000 WHERE Instructor_ID = 10;


-- Course
INSERT INTO Course (Course_Name, Course_Description, Course_Number, Semester, Dep_ID) VALUES
('Database Systems', 'Relational databases and SQL', 'CS101', 'Fall', 1),
('Data Structures', 'Introduction to data structures', 'CS102', 'Spring', 1),
('Systems Analysis', 'Analysis of information systems', 'IS201', 'Fall', 2),
('Linear Algebra', 'Matrices and vectors', 'MATH101', 'Fall', 3),
('Quantum Physics', 'Intro to quantum mechanics', 'PHYS201', 'Spring', 4),
('Marketing Basics', 'Fundamentals of marketing', 'BUS101', 'Fall', 5),
('Financial Accounting', 'Principles of accounting', 'ACC201', 'Spring', 6),
('English Literature', 'Study of English novels', 'ENG101', 'Fall', 7),
('World History', 'Modern history overview', 'HIST101', 'Fall', 8),
('Thermodynamics', 'Heat and energy systems', 'MECH201', 'Spring', 9);

-- Semester
INSERT INTO Semester (Semester_Name, Year) VALUES
('Fall', 2023),
('Spring', 2023),
('Summer', 2023),
('Fall', 2024),
('Spring', 2024),
('Summer', 2024),
('Fall', 2025),
('Spring', 2025),
('Summer', 2025),
('Fall', 2026);

-- Section
INSERT INTO Section (Course_ID, Section_Number, Semester_ID, Instructor_ID) VALUES
(1, 1, 1, 1),
(1, 2, 1, 2),
(2, 1, 2, 1),
(3, 1, 1, 3),
(4, 1, 1, 4),
(5, 1, 2, 5),
(6, 1, 1, 6),
(7, 1, 2, 7),
(8, 1, 1, 8),
(9, 1, 1, 9);

-- Student
INSERT INTO Student (Student_Name, SSN, Current_Address, Current_Phone, Permanent_Address, Permanent_Phone, City, State, ZipCode, BirthDate, Sex, Study_Year, Major_Department) VALUES
('Omar Khaled', 111111111, 'Cairo', '0101111111', 'Alexandria', '0121111111', 'Cairo', 'Cairo', '11111', '2002-01-01', 'Male', 2, 1),
('Mona Ali', 222222222, 'Giza', '0102222222', 'Giza', '0122222222', 'Giza', 'Giza', '22222', '2001-02-02', 'Female', 3, 1),
('Ahmed Samir', 333333333, 'Cairo', '0103333333', 'Cairo', '0123333333', 'Cairo', 'Cairo', '33333', '2003-03-03', 'Male', 1, 2),
('Sara Adel', 444444444, 'Cairo', '0104444444', 'Tanta', '0124444444', 'Cairo', 'Cairo', '44444', '2002-04-04', 'Female', 2, 3),
('Karim Mohamed', 555555555, 'Cairo', '0105555555', 'Mansoura', '0125555555', 'Cairo', 'Cairo', '55555', '2000-05-05', 'Male', 4, 4),
('Hany Gamal', 666666666, 'Cairo', '0106666666', 'Aswan', '0126666666', 'Aswan', 'Aswan', '66666', '2001-06-06', 'Male', 3, 5),
('Nour El-Din', 777777777, 'Cairo', '0107777777', 'Luxor', '0127777777', 'Luxor', 'Luxor', '77777', '2003-07-07', 'Male', 1, 6),
('Laila Tamer', 888888888, 'Cairo', '0108888888', 'Giza', '0128888888', 'Giza', 'Giza', '88888', '2002-08-08', 'Female', 2, 7),
('Salma Hossam', 999999999, 'Cairo', '0109999999', 'Cairo', '0129999999', 'Cairo', 'Cairo', '99999', '2001-09-09', 'Female', 3, 8),
('Tamer Wael', 101010101, 'Cairo', '0101010101', 'Alexandria', '0121010101', 'Alexandria', 'Alex', '10101', '2000-10-10', 'Male', 4, 9);

-- Enrollment (Students registered in Sections)
INSERT INTO Enrollment (Student_ID, Section_ID, Grade) VALUES
(1, 1, 'A'),
(2, 1, 'B'),
(3, 2, 'A'),
(4, 3, 'B+'),
(5, 4, 'C'),
(6, 5, 'A'),
(7, 6, 'B'),
(8, 7, 'A'),
(9, 8, 'A-'),
(10, 9, 'B+');

-- Answer of Questions

-- 1- Perform a report that displays the number of instructor in eachdepartment. 
SELECT D.Dep_Name , COUNT(I.Instructor_ID) AS Num_Instructors
FROM Department D
LEFT JOIN Instructor I ON D.Dep_ID = I.Dep_ID
GROUP BY Dep_Name;


--2- Perform a report that display the department name that offer maximum number of courses. 
SELECT TOP 1 D.Dep_Name, COUNT(C.Course_ID) AS Num_Courses
FROM Department D
JOIN Course C ON D.Dep_ID = C.Dep_ID
GROUP BY D.Dep_Name
ORDER BY Num_Courses DESC;

--3- Perform a report that displays the name of each instructor with the name of courses he teaches 
SELECT I.Instructor_Name, C.Course_Name
FROM Instructor I
JOIN Section S ON I.Instructor_ID = S.Instructor_ID
JOIN Course C ON S.Course_ID = C.Course_ID;



--4- Perform a report that display the number of students in each department.
SELECT D.Dep_Name , COUNT(S.Student_ID) AS Num_Students
FROM Department D 
JOIN Student S ON D.Dep_ID = S.Major_Department
GROUP BY Dep_Name;


--5- Perform a report that display the name of department that pay total maximum salary to his instructors.
SELECT TOP 1 D.Dep_Name, SUM(I.Salary) AS Total_Salary
FROM Department D
JOIN Instructor I ON D.Dep_ID = I.Dep_ID
GROUP BY D.Dep_Name
ORDER BY Total_Salary DESC;


--6- Perform a report that display the Departmrnt name that have maximum number of students. 
SELECT TOP 1 D.Dep_Name, COUNT(S.Student_ID) AS Num_Students
FROM Department D
JOIN Student S ON D.Dep_ID = S.Major_Department
GROUP BY D.Dep_Name
ORDER BY Num_Students DESC;




--7- Perform a report that display the name of instructor that take salary greater than the average salary of his department 
SELECT I.Instructor_Name, I.Salary, D.Dep_Name
FROM Instructor I
JOIN Department D ON I.Dep_ID = D.Dep_ID
WHERE I.Salary > (
    SELECT AVG(I2.Salary) 
    FROM Instructor I2 
    WHERE I2.Dep_ID = I.Dep_ID
);


--8- Perform a report that display department office telephone that hisinstructor earn maximum salary. 
SELECT TOP 1 D.Dep_Name, D.Office_Phone, I.Instructor_Name, I.Salary
FROM Department D
JOIN Instructor I ON D.Dep_ID = I.Dep_ID
ORDER BY I.Salary DESC;



--9- Perform a report that display the name of student who is participant in number of courses that greater than 3 courses 
SELECT S.Student_Name, COUNT(E.Section_ID) AS Num_Courses
FROM Student S
JOIN Enrollment E ON S.Student_ID = E.Student_ID
GROUP BY S.Student_Name
HAVING COUNT(E.Section_ID) > 3;


--10- Perform a report that displays the number of instructor in each course.
SELECT C.Course_Name, COUNT(DISTINCT S.Instructor_ID) AS Num_Instructors
FROM Course C
JOIN Section S ON C.Course_ID = S.Course_ID
GROUP BY C.Course_Name;






