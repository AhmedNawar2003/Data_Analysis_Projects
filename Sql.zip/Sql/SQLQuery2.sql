CREATE TABLE EMP(
EmpID INT PRIMARY KEY IDENTITY(1,1),
EmpName VARCHAR(50),
Department VARCHAR(100),
Salary DECIMAL(10,1),
JobTitle VARCHAR(100));
--TABLE EMP VALUES
INSERT INTO EMP(EmpName,Department,Salary,JobTitle)
VALUES('Ahmed Nawar','Analysis','30000','Data Analyst'),
('Ali Rady','Develoment','20000','Developer'),
('Mohamed Nawar','Security','15000','Defender');

SELECT * FROM EMP;

UPDATE EMP
SET Salary = 18000
WHERE EmpID=7;

DELETE FROM EMP
WHERE EmpID=6;

CREATE TABLE PROJECTS (
    ProjectID INT PRIMARY KEY IDENTITY(1,1),
    ProjectName VARCHAR(100),
    Department VARCHAR(100),
    StartDate DATE,
    EndDate DATE
);
--PROJECTS TABLE VALUES
INSERT INTO PROJECTS (ProjectName, Department, StartDate, EndDate)
VALUES
('Website Development','Development','2025-01-01','2025-06-30'),
('Data Warehouse','Analysis','2025-02-15','2025-07-15'),
('Security Audit','Security','2025-03-01','2025-05-31');

SELECT * FROM PROJECTS;

CREATE TABLE EMP_PROJECTS (
    EmpProjectID INT PRIMARY KEY IDENTITY(1,1),
    EmpID INT,
    ProjectID INT,
    HoursWorked INT,
    FOREIGN KEY (EmpID) REFERENCES EMP(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES PROJECTS(ProjectID)
);
--TABLE EMP_PROJECTS VALUES
INSERT INTO EMP_PROJECTS (EmpID, ProjectID, HoursWorked)
VALUES
(1,2,120), 
(2,1,200), 
(3,3,150),
(1,1,50); 

SELECT * FROM EMP_PROJECTS;

--JOINS Three Tables
SELECT e.EmpName, e.JobTitle, p.ProjectName, ep.HoursWorked
FROM EMP e
JOIN EMP_PROJECTS ep ON e.EmpID = ep.EmpID
JOIN PROJECTS p ON ep.ProjectID = p.ProjectID;

-- 1- INER JOIN
SELECT e.EmpName, p.ProjectName, ep.HoursWorked
FROM EMP e
INNER JOIN EMP_PROJECTS ep ON e.EmpID = ep.EmpID
INNER JOIN PROJECTS p ON ep.ProjectID = p.ProjectID;

-- 2- LEFT JOIN
SELECT e.EmpName, p.ProjectName, ep.HoursWorked
FROM EMP e
LEFT JOIN EMP_PROJECTS ep ON e.EmpID = ep.EmpID
LEFT JOIN PROJECTS p ON ep.ProjectID = p.ProjectID;

-- 1- RIGHT JOIN
SELECT e.EmpName, p.ProjectName, ep.HoursWorked
FROM EMP e
RIGHT JOIN EMP_PROJECTS ep ON e.EmpID = ep.EmpID
RIGHT JOIN PROJECTS p ON ep.ProjectID = p.ProjectID;

-- 1- FULL JOIN
SELECT e.EmpName, p.ProjectName, ep.HoursWorked
FROM EMP e
FULL OUTER JOIN EMP_PROJECTS ep ON e.EmpID = ep.EmpID
FULL OUTER JOIN PROJECTS p ON ep.ProjectID = p.ProjectID;


--Aggregate Function
SELECT e.EmpName,COUNT(*) AS ReatingEmp, SUM(ep.HoursWorked) AS TotalHours
FROM EMP e
JOIN EMP_PROJECTS ep ON e.EmpID = ep.EmpID
GROUP BY e.EmpName;

-- Sub Query
-- Average =118000/5=23600
SELECT EmpName, Salary
FROM EMP
WHERE Salary > (SELECT AVG(Salary) FROM EMP);

-- Window Function
-- 1 - ROW NUMBER()
SELECT  EmpName, Salary,
       ROW_NUMBER() OVER (PARTITION BY EmpName ORDER BY Salary DESC) AS SalaryRank
FROM EMP;

--2- RANK()
SELECT  EmpName, Salary,
       RANK() OVER (PARTITION BY EmpName ORDER BY Salary DESC) AS SalaryRank
FROM EMP;

--3- DENSE RANK()
SELECT  EmpName, Salary,
       DENSE_RANK() OVER (PARTITION BY EmpName ORDER BY Salary DESC) AS SalaryRank
FROM EMP;

-- 4- SUM()
SELECT  e.EmpName, Salary,
       SUM(Salary) OVER (PARTITION BY EmpName ORDER BY Salary DESC) AS SalaryRank
FROM EMP e;

-- CTE [ Common Table Expertions ]
WITH WorkCTE AS (
    SELECT EmpID, SUM(HoursWorked) AS TotalHours
    FROM EMP_PROJECTS
    GROUP BY EmpID
)
SELECT e.EmpName, w.TotalHours
FROM WorkCTE w
JOIN EMP e ON e.EmpID = w.EmpID;


--Indexing
CREATE NONCLUSTERED INDEX idx_emp_projects_empid
ON EMP_PROJECTS(EmpID);

CREATE NONCLUSTERED INDEX idx_emp_projects_projectid
ON EMP_PROJECTS(ProjectID);

