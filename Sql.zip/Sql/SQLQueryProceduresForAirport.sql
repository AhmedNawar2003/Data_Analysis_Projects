-- Procedure 1: GetFlightsInRange
CREATE PROCEDURE GetFlightsInRange
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SELECT Flight_Number, Destination, Date_Of_Fling, Registeration_Number
    FROM Flight
    WHERE Date_Of_Fling BETWEEN @StartDate AND @EndDate;
END;
GO

-- Procedure 2: GetPilotsByDepartment
CREATE PROCEDURE GetPilotsByDepartment
    @DepID INT
AS
BEGIN
    SELECT Pilot_ID, Pilot_Name
    FROM Pilot
    WHERE Dep_ID = @DepID;
END;
GO

-- Procedure 3: GetPlanesByDestination
CREATE PROCEDURE GetPlanesByDestination
    @Destination VARCHAR(50)
AS
BEGIN
    SELECT PL.Model_Number, PL.Registeration_Number
    FROM Flight F
    JOIN Plane PL ON F.Registeration_Number = PL.Registeration_Number
    WHERE F.Destination = @Destination;
END;
GO

-- Procedure 4: GetRecentFlightsToUSA
CREATE PROCEDURE GetRecentFlightsToUSA
AS
BEGIN
    SELECT PL.Model_Number
    FROM Flight F
    JOIN Plane PL ON F.Registeration_Number = PL.Registeration_Number
    WHERE F.Destination = 'USA'
      AND F.Date_Of_Fling BETWEEN DATEADD(DAY, -7, GETDATE()) AND GETDATE();
END;
GO

EXEC GetFlightsInRange '2025-08-01', '2025-08-23';
EXEC GetPilotsByDepartment 2;
EXEC GetPlanesByDestination 'USA';
EXEC GetRecentFlightsToUSA;
