CREATE DATABASE MyEmployees;
GO
USE MyEmployees
GO
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    JobTitle NVARCHAR(100),
    Salary DECIMAL(10,2)
);
INSERT INTO Employees (FirstName, LastName, JobTitle, Salary)
VALUES 
('Ahmed', 'Nawar', 'Developer', 8000),
('Sara', 'Ali', 'Designer', 7000);
SELECT * FROM Employees;
CREATE TABLE Departments (
    DepartmentID INT PRIMARY KEY IDENTITY(1,1),
    DepartmentName NVARCHAR(100)
);
ALTER TABLE Employees
ADD DepartmentID INT;

ALTER TABLE Employees
ADD CONSTRAINT FK_Employees_Departments
FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID);

INSERT INTO Departments (DepartmentName)
VALUES ('IT'), ('HR'), ('Finance');
SELECT * FROM Departments;

INSERT INTO Employees (FirstName, LastName, JobTitle, Salary, DepartmentID)
VALUES 
('Ahmed', 'Nawar', 'Developer', 8000, 1),   
('Sara', 'Ali', 'HR Specialist', 7000, 2), 
('Omar', 'Hassan', 'Accountant', 6000, 3); 
SELECT * FROM Employees;
SELECT * FROM Departments;

--INNER JOIN
SELECT  e.FirstName, e.LastName, d.DepartmentName
FROM Employees e
INNER JOIN Departments d ON e.DepartmentID = d.DepartmentID;

--LEFT JOIN
SELECT  e.FirstName, e.LastName,  d.DepartmentName
FROM Employees e
LEFT JOIN Departments d ON e.DepartmentID = d.DepartmentID;

--ALSO LEFT JOIN
SELECT  e.FirstName, e.LastName,  d.DepartmentName
FROM Departments d
RIGHT JOIN Employees e ON d.DepartmentID = e.DepartmentID;


--RIGHT JOIN
SELECT  e.FirstName, e.LastName,  d.DepartmentName
FROM Employees e
RIGHT JOIN Departments d ON e.DepartmentID = d.DepartmentID;

--ALSO RIGHT JOIN
SELECT  e.FirstName, e.LastName,  d.DepartmentName
FROM Departments d
LEFT JOIN Employees e ON d.DepartmentID = e.DepartmentID;

--FULL JOIN
SELECT  e.FirstName, e.LastName,  d.DepartmentName
FROM Employees e
FULL JOIN Departments d ON e.DepartmentID = d.DepartmentID;

--ALSO FULL JOIN
SELECT  e.FirstName, e.LastName,  d.DepartmentName
FROM Departments d
FULL JOIN Employees e ON d.DepartmentID = e.DepartmentID;


SELECT FirstName AS Name, COUNT(*) AS Number_OF_Salary,SUM(Salary) AS Total_Salary
FROM Employees
GROUP BY FirstName
HAVING SUM(Salary) > 5000;

SELECT FirstName AS Name, COUNT(*) AS Number_OF_Salary,AVG(Salary) AS Average_Of_Salary
FROM Employees
GROUP BY FirstName
HAVING SUM(Salary) > 1000;

--FROM SUB QUERY
SELECT Name , Average_Of_Salary
FROM (
SELECT FirstName AS Name,AVG(Salary) AS Average_Of_Salary
FROM Employees
GROUP BY FirstName
) AS AVG_Salary

SELECT FirstName AS Name,AVG(Salary) AS Average_Of_Salary
FROM Employees
GROUP BY FirstName;

SELECT EmployeeID,FirstName,LastName,JobTitle,Salary,
SUM(Salary) OVER(PARTITION BY EmployeeID ORDER BY Salary DESC) AS Total_Salary
FROM Employees;

