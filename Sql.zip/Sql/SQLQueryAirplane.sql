CREATE DATABASE proj
CREATE TABLE Manager(
	Manager_ID int primary key identity(1,1),
	SSN int not null unique,
	Name char(50) not null,
	Phone int,
	Address char(70));

CREATE TABLE Department(
	Dept_ID int Primary key identity(1,1),
	Dept_Name char(50) not null,
	Manager_ID int,
	FOREIGN KEY (Manager_ID) REFERENCES Manager(Manager_ID));

CREATE TABLE Pilot(
	Pilot_ID int PRIMARY KEY identity(1,1),
	SSN int not null unique,
	License_Num int,
	Name char(50) not null,
	Phone int,
	Address char(70),
	Dept_ID int,
	FOREIGN KEY(Dept_ID) REFERENCES Department(Dept_ID));

CREATE TABLE Plane(
	Regestiration_Num int PRIMARY KEY,
	Model_Num int not null,
	Capacity int,
	Weight int,
	Dept_ID int,
	FOREIGN KEY(Dept_ID) REFERENCES Department(Dept_ID));

CREATE TABLE Flight(
	Flight_Num int PRIMARY KEY,
	Destination char(50) not null,
	Date_Of_Flying date,
	Departure_Time time,
	Arrival_Time time,
	Houres_Flying int,
	Pilot_ID int,
	FOREIGN KEY(Pilot_ID) REFERENCES Pilot(Pilot_ID),
	Dept_ID int,
	FOREIGN KEY(Dept_ID) REFERENCES Department(Dept_ID),
	Regestiration_Num int,
	FOREIGN KEY(Regestiration_Num) REFERENCES Plane(Regestiration_Num));

CREATE TABLE Passengers(
	Passenger_ID int primary Key IDENTITY(1,1),
	Name char(50) not null,
	Phone int,
	Address char(70));

CREATE TABLE Reservation(
	Reservation_ID int primary Key IDENTITY(1,1),
	Seats_Reserve int,
	Passenger_ID int,
	FOREIGN KEY(Passenger_ID) REFERENCES Passengers(Passenger_ID),
	Flight_Num int,
	FOREIGN KEY(Flight_Num) REFERENCES Flight(Flight_Num));

INSERT INTO Manager(SSN,Name,Phone,Address)
VALUES (2,'Omar',01515485,'Mansoura'),
	(5,'Khaled',01894855,'Cairo'),
	(7,'Mohsen',01479521,'alsantah'),
	(10,'felip',01496234,'Talkha');

INSERT INTO Department(Dept_Name,Manager_ID)
VALUES ('NA',1),
	('NA',3),
	('MO',2),
	('MO',4),
	('FE',3)

INSERT INTO Pilot(SSN,License_Num,Name,Phone,Address,Dept_ID)
VALUES(2,123,'Kamel',0156987,'Mansoura',6),
	(5,111,'Mohsen',0145895,'Talkha',7),
	(1,222,'Omar',0158954,'Sandoub',8),
	(4,555,'Youssef',012578,'Mansoura',9),
	(8,999,'Abdullah',01147526,'Mansoura',10);

INSERT INTO Plane(Regestiration_Num,Model_Num,Capacity,Weight,Dept_ID)
VALUES(1,125,30,15550,6),
	(3,589,50,20000,7),
	(5,978,70,30000,9);

INSERT INTO Flight(Flight_Num,Destination,Date_Of_Flying,Departure_Time,Arrival_Time,Regestiration_Num,Dept_ID,Pilot_ID)
VALUES(120,'Talkha','2025-05-05','14:30:00','17:30:00',1,6,2),
	(121,'Mnsoura','2025-05-05','10:20:00','14:50:00',3,7,3),
	(122,'Sandoub','2025-05-05','8:30:00','17:55:00',5,8,1),
	(124,'USA','2025-04-27','8:30:00','17:55:00',5,9,4),
	(123,'USA','2025-05-1','8:30:00','17:55:00',5,9,5),
	(125,'Paris','2025-05-02','14:30:00','17:30:00',1,10,5);
ALTER TABLE Flight
ADD Houres_Flying AS (DATEDIFF(HOUR,Departure_Time,Arrival_Time))

INSERT INTO Passengers(Name,Phone,Address)
VALUES('Ahmed',0154876,'Mansoura'),
	('Mohsen',0189952,'Mansoura'),
	('Khaled',0127995,'Mansoura'),
	('Omar',0147992,'Talkha'),
	('Kamel',014579652,'Talkha');

INSERT INTO Reservation(Seats_Reserve,Passenger_ID,Flight_Num)
VALUES(15,1,121),
	(13,2,121),
	(12,3,122),
	(10,4,122),
	(9,5,120);

--Question 1
--display the name of each pilot and the name of his manager.
SELECT p.Name AS Pilot_Name , m.Name AS Manager_Name
FROM Pilot p
Join Department d ON p.Dept_ID = d.Dept_ID
Left JOIN Manager m ON d.Manager_ID = m.Manager_ID

--Question 2
--display the model number of each plane that will be used in a flight toUSA last week.
SELECT DISTINCT Model_Num
FROM Plane P
JOIN Flight F ON F.Regestiration_Num = P.Regestiration_Num
WHERE Destination = 'USA'
AND Date_Of_Flying BETWEEN DATEADD(DAY,-7,GETDATE()) AND GETDATE()

--Question 3
--display the maximum capacity of the flight number 1200
SELECT Capacity
FROM Plane P
join Flight f ON f.Regestiration_Num = p.Regestiration_Num
WHERE Flight_Num = 120

--Question 4
--Perform a report that display the flight number of first flight to Paris
SELECT TOP 1 Flight_Num
FROM Flight
WHERE Destination = 'Paris'
ORDER BY Date_Of_Flying ASC

--Question 5
-- Perform a report that display a details of pilot information and flight information who will is responsible for.
SELECT Flight_Num,Destination,Date_Of_Flying,o.Pilot_ID,Name,Phone,Address
FROM Flight f
full JOIN plane p ON p.Regestiration_Num = f.Regestiration_Num
LEFT JOIN Pilot o ON o.Dept_ID = p.Dept_ID

--Question 6
--display the flights information that will be arrived after 1 Hours
SELECT * FROM Flight
WHERE Houres_Flying > 1;

--Question 7
-- display the number of pilots in each department
SELECT Dept_Name,COUNT(Pilot_ID) AS Pilots_Number FROM Department d
LEFT JOIN Pilot p ON d.Dept_ID = p.Dept_ID
GROUP BY Dept_Name

--Question 8
--display the number of the planes in each department that arrived in last 3 days
SELECT Dept_Name,COUNT(P.Regestiration_Num) FROM Plane P
JOIN Department d ON P.Dept_ID = D.Dept_ID
LEFT JOIN Flight f ON p.Regestiration_Num = f.Regestiration_Num
WHERE Date_Of_Flying BETWEEN DATEADD(DAY,-3,GETDATE())AND GETDATE()
GROUP BY Dept_Name

--Question 9
--Display the number of passengers in each flight and information about their pilot.

SELECT f.Flight_Num, COUNT(r.Passenger_ID) AS Number_of_Passengers,p.Pilot_ID, p.Name AS Pilot_Name, p.License_Num, p.SSN, p.Address, p.Phone
FROM Flight f
JOIN Reservation r ON f.Flight_Num = r.Flight_Num
JOIN Pilot p ON f.Pilot_ID = p.Pilot_ID
GROUP BY f.Flight_Num, p.Pilot_ID, p.Name, p.License_Num, p.SSN, p.Address, p.Phone;


--Question 10
--display the manager �s name of the department that contains maximum planes of number
SELECT d.Dept_Name AS Department_Name, m.Name AS Manager_Name
FROM Department d
LEFT JOIN Manager m ON d.Manager_ID = m.Manager_ID
WHERE d.Dept_ID = (
SELECT TOP 1 Dept_ID
FROM Plane
GROUP BY Dept_ID
ORDER BY COUNT(Regestiration_Num) DESC);