CREATE TABLE Manager(
Manager_ID INT PRIMARY KEY identity(1,1),
Manager_Name VARCHAR(50) not null,
SSN INT not null unique,
Address VARCHAR(100),
Phone VARCHAR(50)
);

CREATE TABLE Department(
Dep_ID INT PRIMARY KEY identity(1,1),
Dep_Name VARCHAR(50) not null,
Manager_ID INT ,
FOREIGN KEY(Manager_ID) REFERENCES Manager(Manager_ID));



CREATE TABLE Pilot(
Pilot_ID INT PRIMARY KEY identity(1,1),
Pilot_Name VARCHAR(50) not null,
SSN INT not null unique,
Address VARCHAR(100),
Phone VARCHAR(50),
License_Number INT,
Dep_ID INT,
FOREIGN KEY(Dep_ID) REFERENCES Department(Dep_ID)
);

CREATE TABLE Plane(
Registeration_Number INT PRIMARY KEY identity(1,1),
Model_Number INT not null,
Plane_Capacity INT,
Plane_Weight DECIMAL(10,2),
Dep_ID INT,
FOREIGN KEY(Dep_ID) REFERENCES Department(Dep_ID)
);

CREATE TABLE Flight(
Flight_Number INT PRIMARY KEY identity(1,1),
Dep_ID INT ,
FOREIGN KEY(Dep_ID) REFERENCES Department(Dep_ID),
Pilot_ID INT ,
FOREIGN KEY(Pilot_ID) REFERENCES Pilot(Pilot_ID),
Date_Of_Fling DATE,
Registeration_Number INT,
FOREIGN KEY(Registeration_Number) REFERENCES Plane(Registeration_Number),
Departure_Time TIME,
Arrival_Time TIME,
Destination VARCHAR(50) not null,
Houres_Flying DECIMAL(10,1)
);

CREATE TABLE Passenger(
Passenger_ID INT PRIMARY KEY identity(1,1),
Passenger_Name VARCHAR(50) not null,
Passenger_Address VARCHAR(100),
Passenger_Phone VARCHAR(50),
Passenger_Mail VARCHAR(100),
);

CREATE TABLE Reservation(
Reservation_ID INT PRIMARY KEY identity(1,1),
Seats_Reserved INT,
Flight_Number INT,
FOREIGN KEY(Flight_Number) REFERENCES Flight(Flight_Number),
Passenger_ID INT,
FOREIGN KEY(Passenger_ID) REFERENCES Passenger(Passenger_ID)
);

-- Managers
INSERT INTO Manager (Manager_Name, SSN, Address, Phone) VALUES
('Ali Hassan', 111111111, 'Cairo', '0101000001'),
('Sara Mohamed', 222222222, 'Giza', '0101000002'),
('Omar Khaled', 333333333, 'Alexandria', '0101000003'),
('Nour ElDin', 444444444, 'Luxor', '0101000004'),
('Laila Tarek', 555555555, 'Aswan', '0101000005'),
('Hossam Adel', 666666666, 'Cairo', '0101000006'),
('Mona Fathi', 777777777, 'Giza', '0101000007'),
('Ahmed Saad', 888888888, 'Alexandria', '0101000008'),
('Dina Magdy', 999999999, 'Mansoura', '0101000009'),
('Khaled Samir', 123123123, 'Cairo', '0101000010');

-- Departments
INSERT INTO Department (Dep_Name, Manager_ID) VALUES
('Engineering', 1),
('Operations', 2),
('HR', 3),
('Maintenance', 4),
('Logistics', 5),
('Customer Service', 6),
('Security', 7),
('Training', 8),
('Medical', 9),
('Finance', 10);

-- Pilots
INSERT INTO Pilot (Pilot_Name, SSN, Address, Phone, License_Number, Dep_ID) VALUES
('Pilot A', 101010101, 'Cairo', '0111111111', 5001, 1),
('Pilot B', 202020202, 'Giza', '0111111112', 5002, 2),
('Pilot C', 303030303, 'Alex', '0111111113', 5003, 3),
('Pilot D', 404040404, 'Cairo', '0111111114', 5004, 4),
('Pilot E', 505050505, 'Luxor', '0111111115', 5005, 5),
('Pilot F', 606060606, 'Cairo', '0111111116', 5006, 6),
('Pilot G', 707070707, 'Giza', '0111111117', 5007, 7),
('Pilot H', 808080808, 'Alex', '0111111118', 5008, 8),
('Pilot I', 909090909, 'Cairo', '0111111119', 5009, 9),
('Pilot J', 121212121, 'Mansoura', '0111111120', 5010, 10);

-- Planes
INSERT INTO Plane (Model_Number, Plane_Capacity, Plane_Weight, Dep_ID) VALUES
(320, 180, 73500.50, 1),
(737, 200, 80000.75, 2),
(777, 350, 150000.00, 3),
(787, 250, 120000.20, 4),
(319, 150, 70000.00, 5),
(330, 280, 110000.90, 6),
(340, 290, 115000.10, 7),
(350, 300, 125000.50, 8),
(380, 400, 180000.00, 9),
(390, 220, 95000.00, 10);
-- Flights
INSERT INTO Flight (Dep_ID, Pilot_ID, Date_Of_Fling, Registeration_Number, Departure_Time, Arrival_Time, Destination, Houres_Flying) VALUES
(1, 1, '2025-08-15', 1, '08:00:00', '12:00:00', 'USA', 4.0),
(2, 2, '2025-08-16', 2, '09:00:00', '13:30:00', 'Paris', 4.5),
(3, 3, '2025-08-17', 3, '06:00:00', '11:00:00', 'London', 5.0),
(4, 4, '2025-08-18', 4, '15:00:00', '20:00:00', 'USA', 5.0),
(5, 5, '2025-08-19', 5, '07:30:00', '12:30:00', 'Berlin', 5.0),
(6, 6, '2025-08-20', 6, '10:00:00', '16:00:00', 'Tokyo', 6.0),
(7, 7, '2025-08-21', 7, '14:00:00', '18:00:00', 'Paris', 4.0),
(8, 8, '2025-08-22', 8, '11:00:00', '15:00:00', 'Rome', 4.0),
(9, 9, '2025-08-23', 9, '12:00:00', '18:00:00', 'USA', 6.0),
(10, 10, '2025-08-24', 10, '09:30:00', '14:00:00', 'Madrid', 4.5);


-- Passengers
INSERT INTO Passenger (Passenger_Name, Passenger_Address, Passenger_Phone, Passenger_Mail) VALUES
('Ahmed Ali', 'Cairo', '0122000001', 'ahmed@mail.com'),
('Mona Ali', 'Giza', '0122000002', 'mona@mail.com'),
('Omar Ali', 'Cairo', '0122000003', 'omar@mail.com'),
('Sara Ali', 'Alex', '0122000004', 'sara@mail.com'),
('Khaled Ali', 'Luxor', '0122000005', 'khaled@mail.com'),
('Dina Ali', 'Cairo', '0122000006', 'dina@mail.com'),
('Hassan Ali', 'Giza', '0122000007', 'hassan@mail.com'),
('Laila Ali', 'Alex', '0122000008', 'laila@mail.com'),
('Tamer Ali', 'Cairo', '0122000009', 'tamer@mail.com'),
('Nada Ali', 'Mansoura', '0122000010', 'nada@mail.com');

-- Reservations
INSERT INTO Reservation (Seats_Reserved, Flight_Number, Passenger_ID) VALUES
(1, 1, 1),
(2, 1, 2),
(1, 2, 3),
(1, 2, 4),
(3, 3, 5),
(2, 4, 6),
(1, 5, 7),
(2, 6, 8),
(1, 7, 9),
(4, 9, 10);


-- Answer the QUESTIONS

--Question 1
--display the name of each pilot and the name of his manager.
SELECT p.Pilot_Name , m.Manager_Name
FROM Pilot p
Join Department d ON p.Dep_ID = d.Dep_ID
Left JOIN Manager m ON d.Manager_ID = m.Manager_ID

--Question 2
--display the model number of each plane that will be used in a flight toUSA last week.
SELECT DISTINCT Model_Number
FROM Plane P
JOIN Flight F ON F.Registeration_Number = P.Registeration_Number
WHERE Destination = 'USA'
AND Date_Of_Fling BETWEEN DATEADD(DAY,-7,GETDATE()) AND GETDATE()


--Question 3
--display the maximum capacity of the flight number 10
SELECT Plane_Capacity
FROM Plane P
join Flight f ON f.Registeration_Number = p.Registeration_Number
WHERE Flight_Number = 10


--Question 4
--Perform a report that display the flight number of first flight to Paris
SELECT TOP 1 Flight_Number
FROM Flight
WHERE Destination = 'Paris'
ORDER BY Date_Of_Fling ;

SELECT TOP 1 Flight_Number
FROM Flight
WHERE Destination = 'Paris'
ORDER BY Date_Of_Fling DESC;


--Question 5
-- Perform a report that display a details of pilot information and flight information who will is responsible for.
SELECT Flight_Number,Destination,Date_Of_Fling,o.Pilot_ID,Pilot_Name,Phone,Address
FROM Flight f
full JOIN plane p ON p.Registeration_Number = f.Registeration_Number
LEFT JOIN Pilot o ON o.Dep_ID = p.Dep_ID;

--Question 6
--display the flights information that will be arrived after 4 Hours
SELECT * FROM Flight
WHERE Houres_Flying > 4;


--Question 7
-- display the number of pilots in each department
SELECT Dep_Name,COUNT(Pilot_ID) AS Pilots_Number
FROM Department d
LEFT JOIN Pilot p ON d.Dep_ID = p.Dep_ID
GROUP BY Dep_Name;

--Question 8
--display the number of the planes in each department that arrived in last 3 days
SELECT Dep_Name,COUNT(P.Registeration_Number) 
FROM Plane P
JOIN Department d ON P.Dep_ID = D.Dep_ID
LEFT JOIN Flight f ON p.Registeration_Number = f.Registeration_Number
WHERE Date_Of_Fling BETWEEN DATEADD(DAY,-3,GETDATE())AND GETDATE()
GROUP BY Dep_Name

--Question 9
--Display the number of passengers in each flight and information about their pilot.

SELECT f.Flight_Number, COUNT(r.Passenger_ID) AS Number_of_Passengers,
p.Pilot_ID, p.Pilot_Name, p.License_Number, p.SSN, p.Address, p.Phone
FROM Flight f
JOIN Reservation r ON f.Flight_Number = r.Flight_Number
JOIN Pilot p ON f.Pilot_ID = p.Pilot_ID
GROUP BY f.Flight_Number, p.Pilot_Name, p.Pilot_ID, p.License_Number, p.SSN, p.Address, p.Phone;


--Question 10
--display the manager �s name of the department that contains maximum planes of number
SELECT d.Dep_Name, m.Manager_Name
FROM Department d
LEFT JOIN Manager m ON d.Manager_ID = m.Manager_ID
WHERE d.Dep_ID = (
SELECT TOP 1 Dep_ID
FROM Plane
GROUP BY Dep_ID
ORDER BY COUNT(Registeration_Number) DESC);


