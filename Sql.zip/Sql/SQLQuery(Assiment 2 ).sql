
-- Q: 1. Create the employees table to store employee information. 
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    Name VARCHAR(100),
    Gender VARCHAR(10),
    Department VARCHAR(50),
    JobTitle VARCHAR(100),
    Salary DECIMAL(10,2),
    Age INT,
    HireDate DATE
);
-- Q: 2. Insert a new employee into the Employees table. 
INSERT INTO Employees (EmployeeID, Name, Gender, Department, JobTitle, Salary, Age, HireDate)
VALUES 
--(1001, 'Ahmed Nawar', 'Male', 'IT', 'Software Engineer', 15000, 26, '2023-05-15'),
--(1002, 'Sara Ali', 'Female', 'HR', 'HR Specialist', 12000, 29, '2022-03-10'),
--(1003, 'Omar Hassan', 'Male', 'Finance', 'Accountant', 14000, 34, '2021-11-05'),
--(1004, 'Mona Samir', 'Female', 'Marketing', 'Marketing Executive', 13000, 28, '2020-07-18'),
--(1005, 'Khaled Ibrahim', 'Male', 'IT', 'System Administrator', 16000, 32, '2019-09-25'),
--(1006, 'Nadia Fathy', 'Female', 'Security', 'Security Officer', 11000, 41, '2021-01-12'),
(2007, 'Hassan Mahmoud', 'Male', 'Finance', 'Senior Auditor', 18000, 65, '2005-04-10'),
(2008, 'Fatma Youssef', 'Female', 'HR', 'HR Director', 22000, 62, '2000-02-15'),
(2009, 'Ibrahim Salem', 'Male', 'Security', 'Head of Security', 17000, 68, '1998-09-01');

SELECT * 
FROM Base;

-- Q: 3. Select all employees working in the IT department. 
SELECT * 
FROM Employees
WHERE Department = 'IT';

-- APPLY ON BASE 
SELECT * 
FROM Base
WHERE Department = 'IT';

-- Q: 4. Get the average salary for each department.
SELECT Department ,  AVG(Salary) AS AvgDepSalary
FROM Employees
GROUP BY Department
ORDER BY  AVG(Salary) DESC;

-- APPLY ON BASE 
SELECT Department ,  AVG(Salary) AS AvgDepSalary
FROM Base
GROUP BY Department
ORDER BY  AVG(Salary) DESC;

-- Q: 5. Show total salary and employee count per department using GROUP BY and HAVING (only for departments with total salary > 10000). 
SELECT Department , COUNT(*) AS EmployeeCount,
SUM(Salary) AS TotalSalary 
FROM Employees
GROUP BY Department
HAVING SUM(Salary) > 10000
ORDER BY SUM(Salary) DESC;

-- APPLY ON BASE 
SELECT Department ,  COUNT(*) AS EmployeeCount,
SUM(Salary) AS TotalSalary 
FROM Base
GROUP BY Department
HAVING SUM(Salary) > 100000
ORDER BY SUM(Salary) DESC;

-- APPLY ON BASE 
SELECT Department ,  COUNT(*) AS EmployeeCount,
SUM(Salary) AS TotalSalary 
FROM Base
GROUP BY Department
HAVING SUM(Salary) > 100000
ORDER BY COUNT(*) DESC;

-- Q: 6. Perform a JOIN between Employees and Departments to list employee names with their department location. 

--INER JOIN
SELECT e.Name, e.JobTitle, d.DepartmentName, d.Location
FROM Employees e
INNER JOIN sec d ON e.Department = d.DepartmentName;

--LEFT JOIN
SELECT e.Name, e.JobTitle, d.DepartmentName, d.Location
FROM Employees e
LEFT JOIN sec d ON e.Department = d.DepartmentName;

--LEFT JOIN
SELECT e.Name, e.JobTitle, d.DepartmentName, d.Location
FROM Employees e
RIGHT JOIN sec d ON e.Department = d.DepartmentName;

--LEFT JOIN
SELECT e.Name, e.JobTitle, d.DepartmentName, d.Location
FROM Employees e
FULL JOIN sec d ON e.Department = d.DepartmentName;

--APPLY ON BASE

--INER JOIN
SELECT b.Name, b.JobTitle, d.DepartmentName, d.Location
FROM Base b
INNER JOIN sec d ON b.Department = d.DepartmentName;

--LEFT JOIN
SELECT b.Name, b.JobTitle, d.DepartmentName, d.Location
FROM Base b
LEFT JOIN sec d ON b.Department = d.DepartmentName;

--RIGHT JOIN
SELECT b.Name, b.JobTitle, d.DepartmentName, d.Location
FROM Base b
RIGHT JOIN sec d ON b.Department = d.DepartmentName;


--FULL JOIN
SELECT b.Name, b.JobTitle, d.DepartmentName, d.Location
FROM Base b
FULL JOIN sec d ON b.Department = d.DepartmentName;

-- Q: 7. Update salary for an employee with a specific ID. 
UPDATE Employees
SET Salary = 15000
WHERE EmployeeID = 1006;

--APPLY ON BASE
UPDATE Base
SET Salary = 15000
WHERE EmployeeID = 1006;

SELECT *
FROM Employees;

-- Q: 8. Delete employees who are older than 60 years. 
DELETE FROM Employees 
WHERE Age > 60;

--Apply on Base
DELETE FROM Base 
WHERE Age > 60;