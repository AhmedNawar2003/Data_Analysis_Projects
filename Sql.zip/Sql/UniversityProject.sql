CREATE DATABASE University;

CREATE TABLE Department(
    Dep_ID INT PRIMARY KEY IDENTITY(1,1),
    Dep_Name VARCHAR(100) UNIQUE NOT NULL,
    Dep_Code VARCHAR(10) UNIQUE NOT NULL,
    Office_Number VARCHAR(20),
    Office_Phone VARCHAR(20),
    College VARCHAR(100)
);

CREATE TABLE Instructor (
    Instructor_ID INT PRIMARY KEY IDENTITY(1,1),
    Instructor_Name VARCHAR(100) NOT NULL,
    Salary DECIMAL(10,2),
    Dep_ID INT NOT NULL,
    FOREIGN KEY (Dep_ID) REFERENCES Department(Dep_ID)
);

CREATE TABLE Course (
    Course_ID INT PRIMARY KEY IDENTITY(1,1),
    Course_Name VARCHAR(100) NOT NULL,
    Course_Description VARCHAR(500),
    Course_Number VARCHAR(20) UNIQUE NOT NULL,
    Semester VARCHAR(20),
    Dep_ID INT NOT NULL,
    FOREIGN KEY (Dep_ID) REFERENCES Department(Dep_ID)
);

CREATE TABLE Semester(
    Semester_ID INT PRIMARY KEY IDENTITY(1,1),
    Semester_Name VARCHAR(50) NOT NULL,
    Year INT NOT NULL
);

CREATE TABLE Section(
    Section_ID INT PRIMARY KEY IDENTITY(1,1),
    Course_ID INT NOT NULL,
    Section_Number INT NOT NULL,
    Semester_ID INT NOT NULL,
    Instructor_ID INT NOT NULL,
    FOREIGN KEY (Course_ID) REFERENCES Course(Course_ID),
    FOREIGN KEY (Semester_ID) REFERENCES Semester(Semester_ID),
    FOREIGN KEY (Instructor_ID) REFERENCES Instructor(Instructor_ID)
);

CREATE TABLE Student(
    Student_ID INT PRIMARY KEY IDENTITY(1,1),
    Student_Name VARCHAR(100) NOT NULL,
    SSN INT UNIQUE NOT NULL,
    Current_Address VARCHAR(200),
    Current_Phone VARCHAR(20),
    Permanent_Address VARCHAR(200),
    Permanent_Phone VARCHAR(20),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(10),
    BirthDate DATE,
    Sex VARCHAR(10), 
    Study_Year INT,
    Major_Department INT,
    FOREIGN KEY (Major_Department) REFERENCES Department(Dep_ID)
);

CREATE TABLE Enrollment (
    Enrollment_ID INT PRIMARY KEY IDENTITY(1,1),
    Student_ID INT NOT NULL,
    Section_ID INT NOT NULL,
    Grade VARCHAR(5),
    FOREIGN KEY (Student_ID) REFERENCES Student(Student_ID),
    FOREIGN KEY (Section_ID) REFERENCES Section(Section_ID)
);


INSERT INTO Department (Dep_Name, Dep_Code, Office_Number, Office_Phone, College)
VALUES
('Computer Science', 'CS01', 'B101', '0101001001', 'Engineering'),
('Information Systems', 'IS02', 'B102', '0102002002', 'Engineering'),
('Mathematics', 'MATH03', 'C201', '0103003003', 'Science'),
('Business Admin', 'BA04', 'D301', '0104004004', 'Commerce'),
('Physics', 'PH05', 'C202', '0105005005', 'Science'),
('Statistics', 'STAT06', 'C203', '0106006006', 'Science'),
('Accounting', 'ACC07', 'D302', '0107007007', 'Commerce'),
('Marketing', 'MKT08', 'D303', '0108008008', 'Commerce'),
('Economics', 'ECO09', 'D304', '0109009009', 'Commerce'),
('Engineering', 'ENG10', 'E401', '0110001000', 'Engineering');

INSERT INTO Instructor (Instructor_Name,Salary,Dep_ID)
VALUES
('Dr. Ahmed Hassan', 15000,1),
('Dr. Mona Youssef', 17000, 1),
('Dr. Ali Nawar', 12000, 2),
('Dr. Sara Ibrahim', 13000, 2),
('Dr. Hany Mostafa', 14000, 3),
('Dr. Layla Kamal', 20000, 4),
('Dr. Mahmoud Ali', 18000, 4),
('Dr. Eman Tarek', 11000, 5),
('Dr. Samir Adel', 12500, 6),
('Dr. Ali Mohsen' ,16000, 7),
('Dr. Menna Elsayed', 16000, 8),
('Dr. Ahmed Nawar', 16000, 9),
('Dr. Omr Abdallah', 16000, 10);


INSERT INTO Course (Course_Name, Course_Description, Course_Number, Semester, Dep_ID)
VALUES
('Database Systems', 'Relational DB concepts', 'CS101', 'Fall', 1),
('Data Structures', 'Stacks, Queues, Trees', 'CS102', 'Spring', 1),
('Algorithms', 'Sorting, Graphs', 'CS103', 'Fall', 1),
('Information Security', 'Cybersecurity basics', 'IS201', 'Fall', 2),
('Systems Analysis', 'Analysis & Design methods', 'IS202', 'Spring', 2),
('Linear Algebra', 'Matrices & Vectors', 'MATH301', 'Fall', 3),
('Statistics I', 'Introductory statistics', 'STAT401', 'Fall', 6),
('Business Management', 'Principles of management', 'BA501', 'Spring', 4),
('Marketing Principles', 'Marketing basics', 'MKT601', 'Fall', 8),
('Financial Accounting', 'Accounting fundamentals', 'ACC701', 'Spring', 7);

INSERT INTO Semester (Semester_Name, Year)
VALUES
('Fall', 2023),
('Spring', 2024),
('Fall', 2024),
('Spring', 2025);


INSERT INTO Section (Course_ID, Section_Number, Semester_ID, Instructor_ID)
VALUES
(1, 1, 1, 1),
(2, 1, 1, 2), 
(3, 1, 2, 1),
(4, 1, 1, 3), 
(5, 1, 2, 4), 
(6, 1, 1, 5), 
(7, 1, 3, 9), 
(8, 1, 2, 6),
(9, 1, 1, 6), 
(10, 1, 2, 10);


INSERT INTO Student (Student_Name, SSN, Current_Address, Current_Phone, Permanent_Address,
Permanent_Phone, City, State, ZipCode, BirthDate, Sex, Study_Year, Major_Department)
VALUES
('Omar Khaled', 12345, 'Cairo', '0101111111', 'Cairo', '0109999999', 'Cairo', 'Cairo', '11111', '2003-05-12', 'M', 2, 1),
('Nour El-Din', 12346, 'Giza', '0102222222', 'Giza', '0108888888', 'Giza', 'Giza', '22222', '2002-07-21', 'M', 3, 1),
('Yasmin Hany', 12347, 'Alexandria', '0103333333', 'Alex', '0107777777', 'Alex', 'Alex', '33333', '2001-11-01', 'F', 4, 2),
('Khaled Magdy', 12348, 'Cairo', '0104444444', 'Cairo', '0106666666', 'Cairo', 'Cairo', '44444', '2003-09-10', 'M', 2, 2),
('Fatma Samir', 12349, 'Cairo', '0105555555', 'Cairo', '0105555550', 'Cairo', 'Cairo', '55555', '2004-01-15', 'F', 1, 3),
('Hossam Adel', 12350, 'Cairo', '0106666667', 'Cairo', '0104444440', 'Cairo', 'Cairo', '66666', '2002-02-18', 'M', 3, 4),
('Mona Fathi', 12351, 'Cairo', '0107777778', 'Cairo', '0103333330', 'Cairo', 'Cairo', '77777', '2003-03-19', 'F', 2, 4),
('Eslam Ahmed', 12352, 'Cairo', '0108888889', 'Cairo', '0102222220', 'Cairo', 'Cairo', '88888', '2001-04-25', 'M', 4, 5),
('Dina Hassan', 12353, 'Cairo', '0109999990', 'Cairo', '0101111110', 'Cairo', 'Cairo', '99999', '2004-06-30', 'F', 1, 6),
('Mostafa Ali', 12354, 'Cairo', '0101212121', 'Cairo', '0101212100', 'Cairo', 'Cairo', '12121', '2002-12-05', 'M', 3, 7);


INSERT INTO Enrollment (Student_ID, Section_ID, Grade)
VALUES
(1, 1, 'A'),
(1, 2, 'B'),
(1, 3, 'A'),
(1, 4, 'B'),
(2, 1, 'C'),
(2, 2, 'A'),
(3, 4, 'B'),
(3, 5, 'A'),
(4, 5, 'B'),
(5, 6, 'A'),
(6, 8, 'A'),
(7, 9, 'C'),
(8, 7, 'B'),
(9, 7, 'A'),
(10, 10, 'B');

/**************************************************************************/

 --Let's Answer This Questions
 
 -- 1- Perform a report that displays the number of instructor in eachdepartment. 
SELECT D.Dep_Name , COUNT(I.Instructor_ID) AS Num_Instructors
FROM Department D
LEFT JOIN Instructor I ON D.Dep_ID = I.Dep_ID
GROUP BY Dep_Name;


--2- Perform a report that display the department name that offer maximum number of courses. 
SELECT TOP 1 D.Dep_Name, COUNT(C.Course_ID) AS Num_Courses
FROM Department D
JOIN Course C ON D.Dep_ID = C.Dep_ID
GROUP BY D.Dep_Name
ORDER BY Num_Courses DESC;

--3- Perform a report that displays the name of each instructor with the name of courses he teaches 
SELECT I.Instructor_Name, C.Course_Name
FROM Instructor I
JOIN Section S ON I.Instructor_ID = S.Instructor_ID
JOIN Course C ON S.Course_ID = C.Course_ID;



--4- Perform a report that display the number of students in each department.
SELECT D.Dep_Name , COUNT(S.Student_ID) AS Num_Students
FROM Department D 
JOIN Student S ON D.Dep_ID = S.Major_Department
GROUP BY Dep_Name;


--5- Perform a report that display the name of department that pay total maximum salary to his instructors.
SELECT TOP 1 D.Dep_Name, SUM(I.Salary) AS Total_Salary
FROM Department D
JOIN Instructor I ON D.Dep_ID = I.Dep_ID
GROUP BY D.Dep_Name
ORDER BY Total_Salary DESC;


--6- Perform a report that display the Departmrnt name that have maximum number of students. 
SELECT TOP 1 D.Dep_Name, COUNT(S.Student_ID) AS Num_Students
FROM Department D
JOIN Student S ON D.Dep_ID = S.Major_Department
GROUP BY D.Dep_Name
ORDER BY Num_Students DESC;




--7- Perform a report that display the name of instructor that take salary greater than the average salary of his department 
SELECT I.Instructor_Name, I.Salary, D.Dep_Name
FROM Instructor I
JOIN Department D ON I.Dep_ID = D.Dep_ID
WHERE I.Salary > (
    SELECT AVG(I2.Salary) 
    FROM Instructor I2 
    WHERE I2.Dep_ID = I.Dep_ID
)
ORDER BY Salary DESC;


--8- Perform a report that display department office telephone that his instructor earn maximum salary. 
SELECT TOP 1 D.Dep_Name, D.Office_Phone, I.Instructor_Name, I.Salary
FROM Department D
JOIN Instructor I ON D.Dep_ID = I.Dep_ID
ORDER BY I.Salary DESC;



--9- Perform a report that display the name of student who is participant in number of courses that greater than 3 courses 
SELECT S.Student_Name, COUNT(E.Section_ID) AS Num_Courses
FROM Student S
JOIN Enrollment E ON S.Student_ID = E.Student_ID
GROUP BY S.Student_Name
HAVING COUNT(E.Section_ID) > 3;


--10- Perform a report that displays the number of instructor in each course.
SELECT C.Course_Name, COUNT(DISTINCT S.Instructor_ID) AS Num_Instructors
FROM Course C
JOIN Section S ON C.Course_ID = S.Course_ID
GROUP BY C.Course_Name;

/******************************************************************************/

--INDEXING TO OPTMIZE PERFORMANCE

-- Department
CREATE UNIQUE INDEX IX_Department_DepName ON Department(Dep_Name);
CREATE UNIQUE INDEX IX_Department_DepCode ON Department(Dep_Code);

-- Instructor
CREATE NONCLUSTERED INDEX IX_Instructor_DepID ON Instructor(Dep_ID);

-- Course
CREATE UNIQUE INDEX IX_Course_CourseNumber ON Course(Course_Number);
CREATE NONCLUSTERED INDEX IX_Course_DepID ON Course(Dep_ID);

-- Semester
CREATE NONCLUSTERED INDEX IX_Semester_Year_Name ON Semester(Year, Semester_Name);

-- Section
CREATE NONCLUSTERED INDEX IX_Section_CourseID ON Section(Course_ID);
CREATE NONCLUSTERED INDEX IX_Section_SemesterID ON Section(Semester_ID);
CREATE NONCLUSTERED INDEX IX_Section_InstructorID ON Section(Instructor_ID);

-- Student
CREATE UNIQUE INDEX IX_Student_SSN ON Student(SSN);
CREATE NONCLUSTERED INDEX IX_Student_MajorDepartment ON Student(Major_Department);
CREATE NONCLUSTERED INDEX IX_Student_City_State ON Student(City, State);

-- Enrollment
CREATE NONCLUSTERED INDEX IX_Enrollment_StudentID ON Enrollment(Student_ID);
CREATE NONCLUSTERED INDEX IX_Enrollment_SectionID ON Enrollment(Section_ID);


