SELECT * 
FROM bills;

SELECT *
FROM employees$;

-- Q:.1 Find the highest three salaries in our company in Mansoura using LIKE. 
SELECT TOP(3) name AS EmpName, salary AS EmpSalary
FROM employees$ 
WHERE city LIKE '%Mansoura%'
ORDER BY salary DESC;

-- Q:.2 Find the salary of the minimum salary. 
SELECT MIN(salary) AS MinSalary
FROM employees$;

-- Q:.3 Display the number of Employees. 
SELECT COUNT(*) AS TotalEmployees
FROM employees$;

-- Q:.4 Display counting distinct cities. 
SELECT COUNT(DISTINCT city) AS DistinctCities
FROM employees$;

-- Q:.5 Find the Employee who was born before '2-2-2002'. 
SELECT name AS EmpName , dob AS BirthDate 
FROM employees$
WHERE dob < '2002-02-02' ;

-- Q:.6 List the Bills that are not today. 

-- 1- first way
SELECT * 
FROM bills
WHERE bill_date <> CAST(GETDATE() AS DATE);

-- OR 2- second way
SELECT *
FROM bills
WHERE bill_date <> CONVERT(date, GETDATE());


-- OR 3- third way
SELECT *
FROM bills
WHERE bill_date <> FORMAT(GETDATE(), 'yyyy-MM-dd');